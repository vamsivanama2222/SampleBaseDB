package com.example.demo.model;

public class Department {

	private String dept_name;
	private String building;
	private double budget;
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Department(String dept_name, String building, double budget) {
		super();
		this.dept_name = dept_name;
		this.building = building;
		this.budget = budget;
	}
	@Override
	public String toString() {
		return "----" + dept_name + "----" + building + "----" + budget + "----";
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public double getBudget() {
		return budget;
	}
	public void setBudget(double budget) {
		this.budget = budget;
	}
}
