package com.example.demo;

import java.util.Scanner;

import org.apache.catalina.core.ApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.controller.MainController;
import com.example.demo.model.Course;
import com.example.demo.model.Department;
import com.example.demo.model.Instructor;

import java.time.LocalDate;
import java.util.*;

@SpringBootApplication
public class SimpleDbAppApplication {

	private static MainController mainController;
	
	@Autowired
	public SimpleDbAppApplication(MainController mainC)
	{
		SimpleDbAppApplication.mainController=mainC;
	}
	
	public static void localData()
	{
		System.out.println("-------Welcome To Application------");

		
		while(true)
		{
			System.out.println("Main-Menu :)");
			System.out.println("1. View Data");
			System.out.println("2. insert Data");
			System.out.println("3. Update Data");
			System.out.println("4. Delete Data");
			System.out.println("Please select the option...");
			Scanner sc=new Scanner(System.in);
			int ch=sc.nextInt();
			if(ch==1)
			{
				System.out.println("Select the Table Name");
				System.out.println("1. Department");
				System.out.println("2. Course");
				System.out.println("3. Instructor");
				int ch1=sc.nextInt();
				if(ch1==1)
				{
					List<Department> allDept=mainController.allDeptlist();
					for (Department department : allDept) {
						System.out.println(department.toString());
					}
				}
				else if(ch1==2)
				{
					List<Course> allCourse=mainController.getAllCourses();
					for (Course course : allCourse) {
						System.out.println(course.toString());
					}
				}
				else if(ch1==3)
				{
					List<Instructor> instList=mainController.getAllinst();
					for (Instructor instructor : instList) {
						System.out.println(instructor.toString());
					}
				}
				else
				{
					System.out.println("Please select Valid Option");
					System.exit(0);
				}
			}
			else if(ch==2)
			{
				System.out.println("Enter Deparatment Name: ");
				String name=sc.next();
				System.out.println("Enter Dept Building: ");
				String build=sc.next();
				System.out.println("Enter Budjet Amount: ");
				Double budject=sc.nextDouble();
				Department dept=new Department(name,build,budject);
				System.out.println(mainController.insertData(dept));
				
			}
			else if(ch==3)
			{
				System.out.println("Enter Deparatment Name: ");
				String name=sc.next();
				Department dept=mainController.getDept(name);
				if(dept!=null)
				{
					System.out.println(dept.toString());
					System.out.println("Enter the Budject Amount to be Update: ");
					Double amount=sc.nextDouble();
					System.out.println(mainController.updateData(amount, name));
				}
				else
				{
					System.out.println("No record Found");
				}
			}
			else if(ch==4)
			{
				System.out.println("Enter Deparatment Name: ");
				String name=sc.next();
				System.out.println(mainController.deleteData(name));
			}
			else
			{
				System.out.println("Please select Valid Option");
				System.exit(0);
			}
		}
	}
	public static void main(String[] args) {
		SpringApplication.run(SimpleDbAppApplication.class, args);
		
		
		localData();
	}

}
