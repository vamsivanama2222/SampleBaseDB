package com.example.demo.model;

public class Course {

	private String course_id;
	private String title;
	private String dept_name;
	private double credits;
	@Override
	public String toString() {
		return "----" + course_id + "-----" + title + "----" + dept_name + "----"
				+ credits + "----";
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Course(String course_id, String title, String dept_name, double credits) {
		super();
		this.course_id = course_id;
		this.title = title;
		this.dept_name = dept_name;
		this.credits = credits;
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	public double getCredits() {
		return credits;
	}
	public void setCredits(double credits) {
		this.credits = credits;
	}
}
