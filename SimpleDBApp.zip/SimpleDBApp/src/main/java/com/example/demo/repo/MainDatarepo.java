package com.example.demo.repo;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.demo.mapper.Coursemapper;
import com.example.demo.mapper.DepartmentMapper;
import com.example.demo.mapper.InstructorMapper;
import com.example.demo.model.*;

@Repository
public class MainDatarepo {

	@Autowired
	JdbcTemplate template;
	
	@Autowired
	NamedParameterJdbcTemplate namedTemplate;
	
	public String select_dept="select * from department";
	public String select_dept_byname="select * from department where dept_name = :name";
	public String select_course="select * from course";
	public String select_instruct="select * from instructor";
	public String insertDept="insert into department (dept_name,building,budget) values(:name,:build,:budget)";
	public String updateDept="update department set budget=:budget where dept_name=:name";
	public String deleteDept="delete from department where dept_name=:name";
	
	public List<Department> getAllDepartments()
	{
		System.out.println("testtttttttttttttttttttt");
		return template.query(select_dept, new DepartmentMapper());
	}
	public List<Course> getAllCourses()
	{
		return template.query(select_course, new Coursemapper());
	}
	public List<Instructor> getAllInstructors()
	{
		return template.query(select_instruct, new InstructorMapper());
	}
	 public int addDeptIntoDB(Department dept)
	 {
		 MapSqlParameterSource perameter=new MapSqlParameterSource();
		 perameter.addValue("name", dept.getDept_name());
		 perameter.addValue("build", dept.getBuilding());
		 perameter.addValue("budget", dept.getBudget());
		 
		 return namedTemplate.update(insertDept, perameter);
		 
	 }
	 
	 public int updateUserIntoDept(Double budject,String name)
	 {
		 MapSqlParameterSource perameter=new MapSqlParameterSource();
		 perameter.addValue("budget", budject);
		 perameter.addValue("name", name);
		 
		 return namedTemplate.update(updateDept, perameter);
		 
	 }
	 
	 public int deleteDept(String name)
	 {
		 MapSqlParameterSource perameter=new MapSqlParameterSource();
		 perameter.addValue("name", name);
		 
		 return namedTemplate.update(deleteDept, perameter);
	 }
	 
	 public Department  isExistEntity(String name)
	 {
		 MapSqlParameterSource perameter=new MapSqlParameterSource();
		 perameter.addValue("name", name);
		 
		  Department dept=namedTemplate.queryForObject(select_dept_byname, perameter, new DepartmentMapper());
		  return dept;
	 }

}
