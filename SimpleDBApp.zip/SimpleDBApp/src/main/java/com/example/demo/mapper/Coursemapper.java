package com.example.demo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.demo.model.Course;


public class Coursemapper implements RowMapper<Course> {

	@Override
	public Course mapRow(ResultSet rs, int rowNum) throws SQLException {
		Course c=new Course();
		c.setCourse_id(rs.getString("course_id"));
		c.setDept_name(rs.getString("dept_name"));
		c.setTitle(rs.getString("title"));
		c.setCredits(rs.getDouble("credits"));
		return c;
	}

}
