package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Course;
import com.example.demo.model.Department;
import com.example.demo.model.Instructor;
import com.example.demo.repo.MainDatarepo;
import java.util.*;
@RestController
public class MainController {

	@Autowired
	private MainDatarepo dataRepo;
	
	@GetMapping("/alldata")
	public List<Department> allDeptlist()
	{
		//dataRepo=new MainDatarepo();
		System.out.println("testinggggggggggggggggggg");
		return this.dataRepo.getAllDepartments();
	}
	public List<Course> getAllCourses()
	{
		return this.dataRepo.getAllCourses();
	}
	public List<Instructor> getAllinst()
	{
		return this.dataRepo.getAllInstructors();
	}
	
	public String insertData(Department dept)
	{
		int n=this.dataRepo.addDeptIntoDB(dept);
		if(n>0)
		{
			return "Data Added Successfull!";
		}
		return "Something went WRONG:)";
	}
	public String updateData(Double budject ,String name)
	{
		Department isYes=this.dataRepo.isExistEntity(name);
		if(isYes!=null)
		{
			int n=this.dataRepo.updateUserIntoDept(budject,name);
			if(n>0)
			{
				return "Data Updated Successfull!";
			}
			return "Something went WRONG:)";
		}
		
		return "No record Found:))";
	}
	public String deleteData(String name)
	{
		Department isYes=this.dataRepo.isExistEntity(name);
		if(isYes!=null)
		{
			int n=this.dataRepo.deleteDept(name);
			if(n>0)
			{
				return "Data Removed Successfull!";
			}
			return "Something went WRONG:)";
		}
		
		return "No record Found:))";
	}
	public Department getDept(String name)
	{
		return this.dataRepo.isExistEntity(name);
	}
}
