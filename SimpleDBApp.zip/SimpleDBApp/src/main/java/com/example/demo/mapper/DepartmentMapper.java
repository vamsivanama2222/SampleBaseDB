package com.example.demo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.demo.model.Department;

public class DepartmentMapper implements RowMapper<Department> {

	@Override
	public Department mapRow(ResultSet rs, int rowNum) throws SQLException {
	
		Department dept=new Department();
		dept.setBudget(rs.getDouble("budget"));
		dept.setBuilding(rs.getString("building"));
		dept.setDept_name(rs.getString("dept_name"));
		return dept;
	}

}
