package com.example.demo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.demo.model.Instructor;

public class InstructorMapper  implements RowMapper<Instructor>{

	@Override
	public Instructor mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Instructor itr=new Instructor();
		itr.setDept_name(rs.getString("dept_name"));
		itr.setID(rs.getString("ID"));
		itr.setName(rs.getString("name"));
		itr.setSalary(rs.getDouble("salary"));
		return itr;
	}

}
